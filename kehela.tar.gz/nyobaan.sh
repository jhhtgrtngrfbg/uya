#!/bin/sh
#
while [ 1 ]; do
./xlarig -a power2b -o stratum+tcps://stratum-eu.rplant.xyz:17022 -u MrUW1hTR2NkXUP4BaQXoUq6B6Q9HXasD79
.tutung
sleep 5
done